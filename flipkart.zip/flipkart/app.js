// // // // let a=10;
// // // // let b=20;
// // // // let sum=a+b;
// // // // console.log("The sum of a and b is: " + sum);
// // // // media tek wifi 6mt7921 wireless lan card 
// // // // import fs from "fs";
// // // const fs = require("fs");
// // // fs.writeFileSync("sample.txt", "hello pradeep");
// // // console.log("File created");
// // const os=require("os");
// // console.log(os.platform ());
// // import http from "http";
// // const http=require("http");
// // const server=http.createServer((req,res)=>{
// //     res.end("hello pradeep");
// // });
// // server.listen(3000);{
// //     console.log("server is running on http://localhost:3000");
// };
// import http from "http";
const http=require("http");
const fs=require("fs");
const server=http.createServer((req,res)=>{
    fs.readFile("weather.html",(err,data)=>{
        res.end(data);
   // res.end("hello pradeep");//browser will show hello pradeep when we run the server
}); 
});
server.listen(5000);
    console.log("server is running on http://localhost:5000");


    // to take reust client to server 
    // if(req==="/"){
    //     fs.readFile("home.html",(err,data)=>{
    //         res.send(data);
    //     }
    // else if(req==="/order"){
    //     fs.readFile("about.html",(err,data)=>{
    //         res.end(data);
    //     }
    // else if(req==="/cart"){
    //     fs.readFile("cart.html",(err,data)=>{
    //         res.end(data);
    //     }
    // )
    // )
    // }
    // )