const http = require("http");
const fs = require("fs");
const path = require("path");

const pages = {
    "/": "home.html",
    "/home.html": "home.html",
    "/cart.html": "cart.html",
    "/order.html": "order.html"
};

const server = http.createServer(function(req, res) {
    const requestUrl = new URL(req.url, "http://localhost");
    const page = pages[requestUrl.pathname];

    if (!page) {
        res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("Page not found");
        return;
    }

    fs.readFile(path.join(__dirname, page), function(error, data) {
        if (error) {
            console.error("Could not load page:", error);
            res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
            res.end("Could not load the page");
            return;
        }

        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(data);
    });
});

server.listen(5000, function() {
    console.log("Server is running at http://localhost:5000");
});
